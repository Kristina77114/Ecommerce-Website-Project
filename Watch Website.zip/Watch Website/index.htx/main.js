document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        
        const firstName = document.querySelector('#first-name').value;
        const lastName = document.querySelector('#last-name').value;
        const gender = document.querySelector('#gender').value;
        const message = document.querySelector('#message').value;
        const errorMessage = document.querySelector('#error-message');
        
        if (firstName === '' || lastName === '' || gender === '' || message === '') {
            errorMessage.textContent = 'All fields are required.';
            return;
        }
        
        // If validation passes, redirect to about.html
        window.location.href = 'about.html';
    });
});
